#ifndef PERFIL_H
#define PERFIL_H

#include <QDialog>

namespace Ui {
class Perfil;
}

class Perfil : public QDialog
{
    Q_OBJECT

public:
    explicit Perfil(QWidget *parent = nullptr);
    //editar
    void setDatos(QString,QString,QString);
    QString getNombreUsuario();
    QString getApellidoUsuario();
    QString getDniUsuario();
    //QString getUsername();
    ~Perfil();

private slots:
    void on_btnMenu_clicked();

private:
    Ui::Perfil *ui;
    //editar
    QString nombresUsuario;
    QString apellidosUsuario;
    QString dniUsuario;
};

#endif // PERFIL_H
