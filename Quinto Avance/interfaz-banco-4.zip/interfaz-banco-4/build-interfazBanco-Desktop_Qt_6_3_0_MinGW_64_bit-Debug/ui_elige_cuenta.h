/********************************************************************************
** Form generated from reading UI file 'elige_cuenta.ui'
**
** Created by: Qt User Interface Compiler version 6.3.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ELIGE_CUENTA_H
#define UI_ELIGE_CUENTA_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Elige_cuenta
{
public:
    QLabel *label;
    QLabel *label_2;
    QGroupBox *groupBox;
    QGroupBox *groupBox_2;
    QPushButton *pushButton;
    QPushButton *pushButton_2;

    void setupUi(QWidget *Elige_cuenta)
    {
        if (Elige_cuenta->objectName().isEmpty())
            Elige_cuenta->setObjectName(QString::fromUtf8("Elige_cuenta"));
        Elige_cuenta->resize(1292, 673);
        label = new QLabel(Elige_cuenta);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(60, 20, 421, 71));
        QFont font;
        font.setPointSize(48);
        font.setBold(false);
        label->setFont(font);
        label_2 = new QLabel(Elige_cuenta);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(60, 100, 571, 101));
        QFont font1;
        font1.setPointSize(36);
        font1.setBold(true);
        label_2->setFont(font1);
        groupBox = new QGroupBox(Elige_cuenta);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        groupBox->setGeometry(QRect(130, 250, 401, 281));
        QFont font2;
        font2.setPointSize(22);
        font2.setBold(true);
        groupBox->setFont(font2);
        groupBox_2 = new QGroupBox(Elige_cuenta);
        groupBox_2->setObjectName(QString::fromUtf8("groupBox_2"));
        groupBox_2->setGeometry(QRect(710, 250, 411, 281));
        QFont font3;
        font3.setPointSize(20);
        font3.setBold(true);
        groupBox_2->setFont(font3);
        pushButton = new QPushButton(Elige_cuenta);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(230, 560, 191, 61));
        QFont font4;
        font4.setPointSize(26);
        font4.setBold(true);
        pushButton->setFont(font4);
        pushButton_2 = new QPushButton(Elige_cuenta);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(820, 560, 191, 61));
        pushButton_2->setFont(font3);

        retranslateUi(Elige_cuenta);

        QMetaObject::connectSlotsByName(Elige_cuenta);
    } // setupUi

    void retranslateUi(QWidget *Elige_cuenta)
    {
        Elige_cuenta->setWindowTitle(QCoreApplication::translate("Elige_cuenta", "Form", nullptr));
        label->setText(QCoreApplication::translate("Elige_cuenta", "Bienvenido(a) ", nullptr));
        label_2->setText(QCoreApplication::translate("Elige_cuenta", "Elige un tipo de cuenta:", nullptr));
        groupBox->setTitle(QCoreApplication::translate("Elige_cuenta", "Cuenta de ahorros:", nullptr));
        groupBox_2->setTitle(QCoreApplication::translate("Elige_cuenta", "Cuenta de cr\303\251dito:", nullptr));
        pushButton->setText(QCoreApplication::translate("Elige_cuenta", "Elegir", nullptr));
        pushButton_2->setText(QCoreApplication::translate("Elige_cuenta", "Elegir", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Elige_cuenta: public Ui_Elige_cuenta {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ELIGE_CUENTA_H
